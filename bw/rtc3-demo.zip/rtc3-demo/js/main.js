(function() {
  setTimeout(() => {
    var g = $("media-container").hasClass("other-video-holder");
    if (g) {
      console.log("Hello");
    }
  }, 5000);

  //   console.log(g);
})();
